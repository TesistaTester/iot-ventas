
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
    <h3 class="title-header" style="text-transform: uppercase;">
        <i class="fa fa-line-chart"></i>
        <?php echo e($titulo); ?>

        <a href="#" id="btn-imprimir" class="btn btn-sm btn-primary float-right" style="margin-left:10px;"><i class="fa fa-print"></i> IMPRIMIR</a>
        <a href="<?php echo e(url('reportes/')); ?>" class="btn btn-sm btn-secondary float-right" style="margin-left:10px;"><i class="fa fa-arrow-left"></i> ATRAS</a>
    </h3>
    <div class="row">
        <div class="col-12">              
                <!-- inicio card  -->
                <div class="card card-stat">
                    <div class="card-body">
                        <?php if($ventas->count() == 0): ?>
                        <div class="alert alert-info">
                            <div class="media">
                                <img src="<?php echo e(asset('img/alert-info.png')); ?>" class="align-self-center mr-3" alt="...">
                                <div class="media-body">
                                    <h5 class="mt-0">Nota.-</h5>
                                    <p>
                                        NO se tienen items registrados hasta el momento.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <h4 class="text-info text-bold text-center">
                            <?php echo e($titulo); ?>

                            <br>
                            <small>Fecha: <?php echo e(date('d/m/Y H:i:s')); ?></small>
                        </h4>
                        <table class="table table-bordered tabla-datos">
                            <thead>
                            <tr>
                                <th>AÑO</th>
                                <th>MES</th>
                                <th># VENTAS</th>
                                <th>TOTAL VENTAS (Bs)</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">
                                    <?php echo e($item->anio); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->mes); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->cantidad_compras); ?>

                                </td>
                                <td class="text-center decimal-number">
                                    <?php echo e($item->total_ventas); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php endif; ?>

                    </div>
                </div>
                <!-- fin card  -->



        </div>
    </div>
</div>


<script type="text/javascript">
$(function(){
    /*
    -------------------------------------------------------------
    * CONFIGURACION DATA TABLES
    -------------------------------------------------------------
    */
    $('.tabla-datos').DataTable({"language":{url: '<?php echo e(asset('js/datatables-lang-es.json')); ?>'}, "order": [[ 0, "desc" ]]});

    //Conf popover
    $('[data-toggle="popover"]').popover()

    //boton para imprimir
    $('#btn-imprimir').on('click', function () {
        window.print();
    });

    //formateo de numeros
    $('.decimal-number').each(function () {
        let valor = parseFloat($(this).text());

        if (!isNaN(valor)) {
            $(this).text(
                valor.toLocaleString('es-BO', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })
            );
        }
    });


});


</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.autenticado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\TESIS - PROYECTO\iot-inventario\iot-ventas\resources\views/reportes/reporte_ventas_mensual.blade.php ENDPATH**/ ?>