
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
    <h3 class="title-header" style="text-transform: uppercase;">
        <i class="fa fa-home"></i>
        <?php echo e($titulo); ?>

    </h3>
    <div class="row">
        <div class="col-12">
                <!-- inicio card  -->
                <div class="card card-stat">
                    <div class="card-body">
                        <?php if(Auth::user()->usu_rol != 2): ?>

                        <div class="row">
                        <?php if(Auth::user()->usu_rol == 1 || Auth::user()->usu_rol == 4): ?>
                            <div class="col-md-6">
                        <?php endif; ?>
                        <?php if(Auth::user()->usu_rol == 3): ?>
                            <div class="col-md-12">
                        <?php endif; ?>
                                <div class="row">
                                    <div class="title-dash col">
                                    INFORMACIÓN VENTAS 
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e(count($ventas_dia)); ?></h1>
                                            <small># VENTAS DEL DIA</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e(count($ventas_mes)); ?></h1>
                                            <small># VENTAS DEL MES</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e(count($ventas_anio)); ?></h1>
                                            <small># VENTAS DEL AÑO</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e(count($clientes)); ?></h1>
                                            <small>CLIENTES NUEVOS</small>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="box-result-numbers">
                                            <h1 class="decimal-number"><?php echo e($total_ventas_dia); ?></h1>
                                            <small>VENTAS DEL DIA (Bs)</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="box-result-numbers">
                                            <h1 class="decimal-number"><?php echo e($total_ventas_mes); ?></h1>
                                            <small>VENTAS DEL MES (Bs)</small>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="box-result-numbers">
                                            <h1 class="decimal-number"><?php echo e($total_ventas_anio); ?></h1>
                                            <small>VENTAS DEL AÑO (Bs)</small>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <hr>
                                        <h3 class="text-primary"><i class="fa fa-signal"></i> Ventas últimos 7 días</h3>
                                        <canvas id="chart_ventas_diarias"></canvas>
                                    </div>
                                    <div class="col-md-12">
                                    <hr>
                                        <h3 class="text-primary"><i class="fa fa-signal"></i> Ventas últimos 6 meses</h3>
                                        <canvas id="chart_ventas_mensual"></canvas>
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>

                        <?php if(Auth::user()->usu_rol != 3): ?>

                        <?php if(Auth::user()->usu_rol == 1 || Auth::user()->usu_rol == 4): ?>
                            <div class="col-md-6">
                        <?php endif; ?>
                        <?php if(Auth::user()->usu_rol == 2): ?>
                            <div class="col-md-12">
                        <?php endif; ?>
                                <div class="row">
                                    <div class="title-dash col">
                                    INFORMACIÓN ALMACEN
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e($entradas); ?></h1>
                                            <small>INGRESOS DEL DIA</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e($salidas); ?></h1>
                                            <small>SALIDAS DEL DIA</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e($proveedores->count()); ?></h1>
                                            <small>INGRESOS DEL MES</small>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="box-result">
                                            <h1><?php echo e($usuarios->count()); ?></h1>
                                            <small>SALIDAS DEL MES</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <hr>
                                        <h3 class="text-primary"><i class="fa fa-signal"></i> Ingresos del mes</h3>
                                        <canvas id="chart_entradas_mensual"></canvas>
                                    </div>
                                    <div class="col-md-12">
                                        <hr>
                                        <h3 class="text-primary"><i class="fa fa-signal"></i> Salidas del mes</h3>
                                        <canvas id="chart_salidas_mensual"></canvas>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <?php endif; ?>
                            

                    </div>
                </div>
                <!-- fin card  -->



        </div>
    </div>
</div>




<script type="text/javascript">
$(function(){

    //formateo de numeros
    $('.decimal-number').each(function () {
        let valor = parseFloat($(this).text());

        if (!isNaN(valor)) {
            $(this).text(
                valor.toLocaleString('es-BO', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })
            );
        }
    });


    //inicializacion de elementos
    $('#alarma-estado-conectado').hide();
    /*
    -------------------------------------------------------------
    * CONFIGURACION DATA TABLES
    -------------------------------------------------------------
    */
    $('.tabla-datos').DataTable({"language":{url: '<?php echo e(asset('js/datatables-lang-es.json')); ?>'}, "order": [[ 5, "desc" ]]});

    //Conf popover
    $('[data-toggle="popover"]').popover()


});

/*CHART CONFIGURACION EXAMPLE*/
 const labelsDias = [
    //iteramos con blade la variable venta_7_dias
    <?php $__currentLoopData = $ventas_7_dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($venta->dia); ?>',
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   ];
 const labelsMeses = [
    //iteramos con blade la variable venta_6_meses
    <?php $__currentLoopData = $ventas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($venta->mes); ?>',
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   ];
   const data2 = {
     labels: labelsMeses,
     datasets: [{
       label: 'Ventas por mes',
       backgroundColor: 'rgb(5, 99, 132)',
       borderColor: 'rgb(5, 99, 132)',
       data: [
    <?php $__currentLoopData = $ventas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        '<?php echo e($venta->total_ventas); ?>',
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       ],
     }]
   };

    const dataDiario = {
      labels: labelsDias,
      datasets: [{
         label: 'Ventas por día',
         backgroundColor: 'rgb(54, 162, 235)',
         borderColor: 'rgb(54, 162, 235)',
         data: [
     <?php $__currentLoopData = $ventas_7_dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          '<?php echo e($venta->total_ventas); ?>',
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         ],
      }]
    };

   const data3 = {
     labels: [
        <?php $__currentLoopData = $entradas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($entrada->mes); ?>',   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     ],
     datasets: [{
       label: 'Entradas por mes',
       backgroundColor: 'rgb(4, 189, 72)',
       borderColor: 'rgb(4, 189, 72)',
       data: [
        <?php $__currentLoopData = $entradas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($entrada->total_entradas); ?>',   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       ],
     }]
   };

   const data4 = {
     labels: [
        <?php $__currentLoopData = $salidas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($salida->mes); ?>',   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     ],
     datasets: [{
       label: 'Salidas por mes',
       backgroundColor: 'rgb(4, 189, 72)',
       borderColor: 'rgb(4, 189, 72)',
       data: [
        <?php $__currentLoopData = $salidas_6_meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($salida->total_salidas); ?>',   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       ],
     }]
   };


    const config_diario = {
      type: 'bar',
      data: dataDiario,
      options: {}
    };

   const config_mensual = {
     type: 'bar',
     data: data2,
     options: {}
   };

   const config_entradas_mensual = {
     type: 'bar',
     data: data3,
     options: {}
   };

   const config_salidas_mensual = {
     type: 'bar',
     data: data4,
     options: {}
   };

    <?php if(Auth::user()->usu_rol != 2): ?> 
    const grafico_ventas_mensual = new Chart(
        document.getElementById('chart_ventas_mensual'),
        config_mensual
      );

    const grafico_ventas_diarias = new Chart(
        document.getElementById('chart_ventas_diarias'),
        config_diario
    );
    <?php endif; ?>

    <?php if(Auth::user()->usu_rol != 3): ?> 
    const grafico_entradas_mensual = new Chart(
        document.getElementById('chart_entradas_mensual'),
        config_entradas_mensual
      );

    const grafico_salidas_mensual = new Chart(
        document.getElementById('chart_salidas_mensual'),
        config_salidas_mensual
      );
      <?php endif; ?>
      

</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.autenticado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\TESIS - PROYECTO\iot-inventario\iot-ventas\resources\views/dashboard/detalle_tablero.blade.php ENDPATH**/ ?>