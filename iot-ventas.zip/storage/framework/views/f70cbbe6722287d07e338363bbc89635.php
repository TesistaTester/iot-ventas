
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
		<h3 class="title-header" style="text-transform: uppercase;">
			<i class="fa fa-plus"></i>
			<?php echo e($titulo); ?>

			<a href="<?php echo e(url('proveedores')); ?>" title="Volver a lista de proveedores" data-placement="bottom" class="btn btn-sm btn-secondary float-right" style="margin-left:10px;"><i class="fa fa-angle-double-left"></i> ATRÁS</a>
		</h3>

		<div class="row">
			<div class="col-md-12">
				<!-- inicio card  -->
				<div class="card">
					<div class="row no-gutters">
						<div class="col-md-12">
							<div class="card-body">
								<form id="form-nuevo-proveedor" action="<?php echo e(url('proveedores')); ?>" method="POST">
								  <?php echo csrf_field(); ?>
								  <section id="seccion-datos-proveedor">
									<h4 class="card-title"><strong><span class="text-primary">
										<i class="fa fa-database"></i>
										Datos del proveedor
									</span></strong></h4>
									<hr>
									<div class="row">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Nombre del proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el nombre del proveedor"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pve_nombre')); ?>" class="form-control <?php $__errorArgs = ['pve_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_nombre" id="pve_nombre" placeholder="Nombre del proveedor">
														<?php $__errorArgs = ['pve_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															NIT Proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el NIT o CI del proveedor"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pve_nit')); ?>" class="form-control <?php $__errorArgs = ['pve_nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_nit" id="pve_nit" placeholder="NIT Proveedor">
														<?php $__errorArgs = ['pve_nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Telefono proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el telefono del proveedor"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pve_telefono')); ?>" class="form-control <?php $__errorArgs = ['pve_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_telefono" id="pve_telefono" placeholder="Telefono proveedor">
														<?php $__errorArgs = ['pve_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Email Proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el email del proveedor"></i>
														</label>
														<input required type="email" value="<?php echo e(old('pve_email')); ?>" class="form-control <?php $__errorArgs = ['pve_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_email" id="pve_email" placeholder="Email proveedor">
														<?php $__errorArgs = ['pve_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-8">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Direccion Proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer la direccion del proveedor"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pve_direccion')); ?>" class="form-control <?php $__errorArgs = ['pve_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_direccion" id="pve_direccion" placeholder="Direccion proveedor">
														<?php $__errorArgs = ['pve_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>

											</div>
											
											<div class="row">
												<div class="col-md-6">
													<button type="submit" class="btn btn-primary">
															<i class="fa fa-save"></i>
															Guardar datos
													</button>
												</div>
											</div>

										</div>
									</div>

								  </section>


								  
								</form>
							</div>
						</div>
					</div>
				</div>

				<!-- fin card  -->

			</div>
		</div>
	</div>

<script>
$(function(){

});	


	</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autenticado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\TESIS - PROYECTO\iot-inventario\iot-ventas\resources\views/proveedores/form_nuevo_proveedor.blade.php ENDPATH**/ ?>