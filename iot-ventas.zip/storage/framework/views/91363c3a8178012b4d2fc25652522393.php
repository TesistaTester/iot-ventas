
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
		<h3 class="title-header" style="text-transform: uppercase;">
			<i class="fa fa-plus"></i>
			<?php echo e($titulo); ?>

			<a href="<?php echo e(url('productos')); ?>" title="Volver a lista de productos" data-placement="bottom" class="btn btn-sm btn-secondary float-right" style="margin-left:10px;"><i class="fa fa-angle-double-left"></i> ATRÁS</a>
		</h3>

		<div class="row">
			<div class="col-md-12">
				<!-- inicio card  -->
				<div class="card">
					<div class="row no-gutters">
						<div class="col-md-12">
							<div class="card-body">
								<form id="form-nuevo-producto" action="<?php echo e(url('ventas')); ?>" method="POST">
								  <?php echo csrf_field(); ?>
								  <section id="seccion-datos-cuenta-modulo-lectura">
									<div class="row">
										<div class="col-md-12">
											<h5 class="card-title"><strong><span class="text-primary">
												<i class="fa fa-user"></i>
												Datos del cliente
											</span></strong></h5>
											<hr>
											<div class="row">
												<div class="col-md-3">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Nombre cliente:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el nombre del cliente"></i>
														</label>
														<input required type="text" value="<?php echo e(old('cli_nombre')); ?>" class="form-control <?php $__errorArgs = ['cli_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cli_nombre" id="cli_nombre" placeholder="Nombre del cliente">
														<?php $__errorArgs = ['cli_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															NIT/CI:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el nro de documento"></i>
														</label>
														<input required type="text" value="<?php echo e(old('cli_nro_documento')); ?>" class="form-control <?php $__errorArgs = ['cli_nro_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cli_nro_documento" id="cli_nro_documento" placeholder="Nro documento">
														<?php $__errorArgs = ['cli_nro_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Telefono/celular:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el telefono del cliente"></i>
														</label>
														<input required type="text" value="<?php echo e(old('cli_telefono')); ?>" class="form-control <?php $__errorArgs = ['cli_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cli_telefono" id="cli_telefono" placeholder="Telefono cliente">
														<?php $__errorArgs = ['cli_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-3">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Email:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el email del cliente"></i>
														</label>
														<input required type="text" value="<?php echo e(old('cli_email')); ?>" class="form-control <?php $__errorArgs = ['cli_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cli_email" id="cli_email" placeholder="Email cliente">
														<?php $__errorArgs = ['cli_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												
											</div>
											<h5 class="card-title"><strong><span class="text-primary">
												<i class="fa fa-dollar"></i>
												Datos de la venta
											</span></strong></h5>
											<hr>
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Fecha venta:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer la descripcion del producto"></i>
														</label>
														<input required type="date" value="<?php echo e(old('ven_fecha_venta', date('Y-m-d'))); ?>" class="form-control <?php $__errorArgs = ['ven_fecha_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ven_fecha_venta" id="ven_fecha_venta" placeholder="Fecha de venta">
														<?php $__errorArgs = ['ven_fecha_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Metodo pago:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el precio de venta"></i>
														</label>
														<select required class="form-control <?php $__errorArgs = ['ven_metodo_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ven_metodo_pago" id="ven_metodo_pago">
															<option value="">Seleccione una opción</option>
															<option value="Efectivo" <?php echo e(old('ven_metodo_pago') == 'Efectivo' ? 'selected' : ''); ?> selected>Efectivo</option>
															<option value="Transferencia Bancaria" <?php echo e(old('ven_metodo_pago') == 'Transferencia Bancaria' ? 'selected' : ''); ?>>Transferencia Bancaria</option>
															<option value="QR" <?php echo e(old('ven_metodo_pago') == 'QR' ? 'selected' : ''); ?>>QR</option>
														</select>
														<?php $__errorArgs = ['ven_metodo_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												

											</div>

											
											<div class="row">
												<div class="col-md-6 offset-md-3 text-center">
													<button type="button" data-toggle="modal" data-target="#modal-detalle-venta" class="btn btn-primary btn-lg">
															<i class="fa fa-shopping-cart"></i>
															Llenar Carrito
													</button>
												</div>
											</div>

										</div>
									</div>

								  </section>



<div class="modal fade" id="modal-detalle-venta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eee;">
          <h5 class="modal-title text-primary">
              <i class="fa fa-shopping-cart"></i>
              Carrito de compra
            </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
						<div class="row">
							<div class="col-md-6 offset-md-3">
								<div class="box-data-xtra">
									<h2>Total compra (Bs): <span class="box-result-numbers" style="padding:3px;" id="total-compra">0,00</span></h2>
									<input type="hidden" name="carrito_json" id="carrito_json">
									
								</div>
							</div>
							<div class="col-md-3 text-right">
								<button type="submit" class="btn btn-success btn-lg" id="btn-enviar-carrito">
									<i class="fa fa-save"></i>
									Registrar compra
								</button>
							</div>
						</div>
                        <table class="table table-bordered tabla-carrito">
                            <thead>
                            <tr>
                                <th>ID PROD</th>
                                <th>SKU</th>
                                <th>PRODUCTO</th>
                                <th>PRECIO VENTA</th>
                                <th>CANTIDAD</th>
                                <th>AGREGAR</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $inventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr
								class="item-carrito"
								data-id="<?php echo e($item->producto->pro_id); ?>"
								data-precio="<?php echo e($item->producto->pro_precio_venta); ?>"
							>
                                <td class="text-center">
                                    <?php echo e($item->producto->pro_id); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->producto->pro_sku); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->producto->pro_nombre); ?>

                                </td>
                                <td class="text-center">
                                    <?php echo e($item->producto->pro_precio_venta); ?>

                                </td>
                                <td class="text-center cantidad">
                                    <?php echo e($item->inv_cantidad); ?>

                                </td>
                                <td>
									<div class="input-group cantidad-item" 
										data-id="<?php echo e($item->producto->pro_id); ?>"
										data-max="<?php echo e($item->inv_cantidad); ?>">
										<div class="input-group-prepend">
											<button class="btn btn-outline-secondary btn-minus" type="button">−</button>
										</div>

										<input type="number" class="form-control text-center input-cantidad"
											value="0" min="0" max="<?php echo e($item->inv_cantidad); ?>">

										<div class="input-group-append">
											<button class="btn btn-outline-secondary btn-plus" type="button">+</button>
										</div>
									</div>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
			
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  





								  
								</form>
							</div>
						</div>
					</div>
				</div>

				<!-- fin card  -->

			</div>
		</div>
	</div>



<script>
$(function(){
    $('.tabla-carrito').DataTable({"language":{url: '<?php echo e(asset('js/datatables-lang-es.json')); ?>'}, "order": [[ 0, "desc" ]]});

	$('#btn-enviar-carrito').attr('disabled','disabled');

	function actualizarCarrito() {
		let carrito = [];
		let total = 0;

		$('.item-carrito').each(function () {
			let fila = $(this);
			let cantidad = parseInt(fila.find('.input-cantidad').val()) || 0;

			if (cantidad > 0) {
				let productoId = fila.data('id');
				let precio = parseFloat(fila.data('precio'));
				let subtotal = precio*cantidad;

				carrito.push({
					producto_id: productoId,
					precio_unitario: precio,
					cantidad: cantidad,
					subtotal: subtotal,
				});

				total += precio * cantidad;
			}
		});

		// Guardar JSON en input hidden
		$('#carrito_json').val(JSON.stringify(carrito));

		// Mostrar total
		$('#total-compra').text(total.toLocaleString('es-BO', {
			minimumFractionDigits: 2,
			maximumFractionDigits: 2
		}));


		if(total == 0){
			$('#btn-enviar-carrito').attr('disabled','disabled');
		}else{
			$('#btn-enviar-carrito').removeAttr('disabled');
		}
	}


	// Botón +
    $(document).on('click', '.btn-plus', function () {
		let grupo = $(this).closest('.cantidad-item');
		let input = grupo.find('.input-cantidad');

		let max = parseInt(grupo.data('max'));
		let valor = parseInt(input.val()) || 0;

		if (valor < max) {
			input.val(valor + 1);
			actualizarCarrito();
		}	
	});

    // Botón -
    $(document).on('click', '.btn-minus', function () {
		let grupo = $(this).closest('.cantidad-item');
		let input = grupo.find('.input-cantidad');

		let valor = parseInt(input.val()) || 0;

		if (valor > 0) {
			input.val(valor - 1);
			actualizarCarrito();
		}		
    });

	$(document).on('input', '.input-cantidad', function () {
		let grupo = $(this).closest('.cantidad-item');
		let max = parseInt(grupo.data('max'));
		let valor = parseInt($(this).val()) || 1;

		if (valor < 0) valor = 0;
		if (valor > max) valor = max;

		$(this).val(valor);
		actualizarCarrito();
				
	});

	$(document).on('change', '.input-cantidad', function () {
		let grupo = $(this).closest('.cantidad-item');
		let max = parseInt(grupo.data('max'));
		let valor = parseInt($(this).val());

		grupo.find('.btn-plus').prop('disabled', valor >= max);
		grupo.find('.btn-minus').prop('disabled', valor <= 0);
	});



});	


	</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autenticado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\TESIS - PROYECTO\iot-inventario\iot-ventas\resources\views/ventas/form_nueva_venta.blade.php ENDPATH**/ ?>