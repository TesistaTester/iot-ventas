
<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="col-md-10 content-pane">
		<h3 class="title-header" style="text-transform: uppercase;">
			<i class="fa fa-plus"></i>
			<?php echo e($titulo); ?>

			<a href="<?php echo e(url('productos')); ?>" title="Volver a lista de productos" data-placement="bottom" class="btn btn-sm btn-secondary float-right" style="margin-left:10px;"><i class="fa fa-angle-double-left"></i> ATRÁS</a>
		</h3>

		<div class="row">
			<div class="col-md-12">
				<!-- inicio card  -->
				<div class="card">
					<div class="row no-gutters">
						<div class="col-md-12">
							<div class="card-body">
								<form id="form-nuevo-producto" action="<?php echo e(url('productos')); ?>" method="POST">
								  <?php echo csrf_field(); ?>
								  <section id="seccion-datos-cuenta-modulo-lectura">
									<h4 class="card-title"><strong><span class="text-primary">
										<i class="fa fa-database"></i>
										Datos del producto
									</span></strong></h4>
									<hr>
									<div class="row">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Nombre del producto:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer una descripcion del modulo de lectura"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pro_nombre')); ?>" class="form-control <?php $__errorArgs = ['pro_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_nombre" id="pro_nombre" placeholder="Nombre del producto">
														<?php $__errorArgs = ['pro_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Proveedor:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer una descripcion del modulo de lectura"></i>
														</label>
														<select required class="form-control <?php $__errorArgs = ['pve_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pve_id" id="pve_id">
															<option value="">Seleccione una opción</option>
															<?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($item->pve_id); ?>" <?php echo e(old('pve_id') == $item->pve_id ? 'selected' : ''); ?>><?php echo e($item->pve_nombre); ?></option>																
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</select>
														<?php $__errorArgs = ['pve_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															SKU:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer una descripcion del modulo de lectura"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pro_sku')); ?>" class="form-control <?php $__errorArgs = ['pro_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_sku" id="pro_sku" placeholder="SKU Producto">
														<?php $__errorArgs = ['pro_sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Descripcion del producto:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer la descripcion del producto"></i>
														</label>
														<input required type="text" value="<?php echo e(old('pro_descripcion')); ?>" class="form-control <?php $__errorArgs = ['pro_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_descripcion" id="pro_descripcion" placeholder="Descripcion producto">
														<?php $__errorArgs = ['pro_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>

											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Precio venta:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el precio de venta"></i>
														</label>
														<input required type="number" step="0.1" value="<?php echo e(old('pro_precio_venta')); ?>" class="form-control <?php $__errorArgs = ['pro_precio_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_precio_venta" id="pro_precio_venta" placeholder="Precio de venta">
														<?php $__errorArgs = ['pro_precio_venta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Precio compra:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer el precio de compra"></i>
														</label>
														<input required type="number" step="0.1" value="<?php echo e(old('pro_precio_compra')); ?>" class="form-control <?php $__errorArgs = ['pro_precio_compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_precio_compra" id="pro_precio_compra" placeholder="Precio de compra">
														<?php $__errorArgs = ['pro_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
												<div class="col-md-4">
													<div class="form-group">
														<label class="label-blue label-block" for="">
															Stock Minimo:
															<span class="text-danger">*</span>
															<i class="fa fa-question-circle float-right" title="Establecer una descripcion del modulo de lectura"></i>
														</label>
														<input required type="number" step="1" value="<?php echo e(old('pro_stock_minimo')); ?>" class="form-control <?php $__errorArgs = ['pro_stock_minimo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_stock_minimo" id="pro_stock_minimo" placeholder="Stock minimo">
														<?php $__errorArgs = ['pro_stock_minimo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<div class="invalid-feedback">
															<?php echo e($message); ?>

														</div>											
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													</div>
												</div>
											</div>

											
											<div class="row">
												<div class="col-md-6">
													<button type="submit" class="btn btn-primary">
															<i class="fa fa-save"></i>
															Guardar datos
													</button>
												</div>
											</div>

										</div>
									</div>

								  </section>


								  
								</form>
							</div>
						</div>
					</div>
				</div>

				<!-- fin card  -->

			</div>
		</div>
	</div>

<script>
$(function(){

});	


	</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.autenticado', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\TESIS - PROYECTO\iot-inventario\iot-ventas\resources\views/productos/form_nuevo_producto.blade.php ENDPATH**/ ?>